import { MailService } from '@sendgrid/mail';
import type { Booking, Venue, User } from '@shared/schema';

const mailService = process.env.SENDGRID_API_KEY ? new MailService() : null;
if (mailService && process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

const FROM_EMAIL = process.env.FROM_EMAIL || 'noreply@shaadipalace.pk';

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

async function sendEmail(params: EmailParams): Promise<boolean> {
  if (!mailService) {
    console.log('Email service not configured. Would send email:', {
      to: params.to,
      subject: params.subject,
      preview: params.html?.substring(0, 100) + '...'
    });
    return true; // Return success for testing without actual email service
  }
  
  try {
    await mailService.send({
      to: params.to,
      from: params.from,
      subject: params.subject,
      text: params.text,
      html: params.html,
    });
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    return false;
  }
}

export async function sendBookingConfirmation(
  email: string,
  booking: Booking,
  venue: Venue,
  user: User
): Promise<boolean> {
  const eventTypeNames = {
    mehndi: 'Mehndi Ceremony',
    nikah: 'Nikah Ceremony',
    walima: 'Walima Reception',
    reception: 'Reception'
  };

  const eventTypeName = eventTypeNames[booking.eventType as keyof typeof eventTypeNames] || booking.eventType;
  
  const subject = `Booking Confirmation - ${eventTypeName} at ${venue.name}`;
  
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Booking Confirmation</title>
        <style>
            body { font-family: 'Inter', Arial, sans-serif; line-height: 1.6; color: #1a5f3f; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #006A4E 0%, #228B22 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .header h1 { margin: 0; font-size: 28px; font-weight: bold; }
            .header .urdu { font-size: 16px; margin-top: 5px; opacity: 0.9; }
            .content { background: #f8fffe; padding: 30px; border-radius: 0 0 10px 10px; }
            .booking-details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #FFD700; }
            .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #eee; }
            .detail-label { font-weight: 600; color: #1a5f3f; }
            .detail-value { color: #333; }
            .amount { font-size: 24px; font-weight: bold; color: #006A4E; }
            .footer { text-align: center; margin-top: 30px; padding: 20px; background: #006A4E; color: white; border-radius: 8px; }
            .islamic-blessing { background: #fff8e1; padding: 15px; border-radius: 8px; margin: 20px 0; text-align: center; font-style: italic; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Booking Confirmed!</h1>
                <div class="urdu">بکنگ کی تصدیق</div>
                <p>Alhamdulillah! Your wedding celebration is confirmed</p>
            </div>
            
            <div class="content">
                <p>Dear ${user.firstName || 'Valued Customer'},</p>
                <p>Assalamu Alaikum! We are delighted to confirm your booking for your special celebration. May Allah bless your union with happiness and prosperity.</p>
                
                <div class="booking-details">
                    <h3 style="color: #006A4E; margin-top: 0;">Booking Details</h3>
                    <div class="detail-row">
                        <span class="detail-label">Event Type:</span>
                        <span class="detail-value">${eventTypeName}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Venue:</span>
                        <span class="detail-value">${venue.name}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Event Date:</span>
                        <span class="detail-value">${new Date(booking.eventDate).toLocaleDateString('en-US', { 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Guest Count:</span>
                        <span class="detail-value">${booking.guestCount} guests</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Total Amount:</span>
                        <span class="detail-value amount">₨${Number(booking.totalAmount).toLocaleString()}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Booking ID:</span>
                        <span class="detail-value">${booking.id}</span>
                    </div>
                </div>

                <div class="islamic-blessing">
                    <p>"وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً"</p>
                    <p><em>"And among His signs is that He created for you mates from among yourselves, that you may dwell in tranquility with them, and He has put love and mercy between your hearts."</em></p>
                    <p style="margin: 0;"><strong>- Surah Ar-Rum (30:21)</strong></p>
                </div>

                <p><strong>What happens next?</strong></p>
                <ul>
                    <li>Our team will contact you within 24 hours to discuss event details</li>
                    <li>You can complete your payment through our secure payment portal</li>
                    <li>We'll coordinate with you on all cultural and Islamic requirements</li>
                    <li>Final venue walkthrough will be scheduled closer to your event date</li>
                </ul>

                <p>If you have any questions or special requirements, please don't hesitate to contact us.</p>
            </div>

            <div class="footer">
                <p><strong>Shaadi Palace</strong></p>
                <p>Making Pakistani wedding dreams come true</p>
                <p>📞 +92 321 1234567 | 📧 info@shaadipalace.pk</p>
                <p style="margin: 0;">JazakAllahu Khairan for choosing us for your special day!</p>
            </div>
        </div>
    </body>
    </html>
  `;

  return await sendEmail({
    to: email,
    from: FROM_EMAIL,
    subject,
    html
  });
}

export async function sendPaymentConfirmation(
  email: string,
  booking: Booking,
  venue: Venue,
  user: User
): Promise<boolean> {
  const subject = `Payment Confirmed - ${venue.name}`;
  
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Payment Confirmation</title>
        <style>
            body { font-family: 'Inter', Arial, sans-serif; line-height: 1.6; color: #1a5f3f; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #FFD700 0%, #DAA520 100%); color: #1a5f3f; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .header h1 { margin: 0; font-size: 28px; font-weight: bold; }
            .content { background: #f8fffe; padding: 30px; border-radius: 0 0 10px 10px; }
            .payment-details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #006A4E; }
            .amount { font-size: 32px; font-weight: bold; color: #006A4E; text-align: center; margin: 20px 0; }
            .success-icon { font-size: 48px; color: #28a745; text-align: center; margin: 20px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div class="success-icon">✅</div>
                <h1>Payment Confirmed!</h1>
                <div class="urdu">ادائیگی کی تصدیق</div>
            </div>
            
            <div class="content">
                <p>Dear ${user.firstName || 'Valued Customer'},</p>
                <p>Alhamdulillah! Your payment has been successfully processed.</p>
                
                <div class="amount">₨${Number(booking.totalAmount).toLocaleString()}</div>
                
                <div class="payment-details">
                    <h3 style="color: #006A4E; margin-top: 0;">Payment Summary</h3>
                    <p><strong>Booking ID:</strong> ${booking.id}</p>
                    <p><strong>Venue:</strong> ${venue.name}</p>
                    <p><strong>Event Date:</strong> ${new Date(booking.eventDate).toLocaleDateString()}</p>
                    <p><strong>Payment Status:</strong> <span style="color: #28a745; font-weight: bold;">CONFIRMED</span></p>
                </div>

                <p>Your booking is now fully confirmed. We look forward to making your special day memorable!</p>
            </div>
        </div>
    </body>
    </html>
  `;

  return await sendEmail({
    to: email,
    from: FROM_EMAIL,
    subject,
    html
  });
}
