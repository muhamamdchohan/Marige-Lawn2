import {
  users,
  venues,
  bookings,
  payments,
  reviews,
  packages,
  type User,
  type UpsertUser,
  type Venue,
  type Booking,
  type Payment,
  type Review,
  type Package,
  type InsertVenue,
  type InsertBooking,
  type InsertPayment,
  type InsertReview
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, asc, like, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, stripeData: { customerId: string; subscriptionId: string }): Promise<User>;

  // Venue operations
  getVenues(): Promise<Venue[]>;
  getVenue(id: string): Promise<Venue | undefined>;
  createVenue(venue: InsertVenue): Promise<Venue>;
  updateVenue(id: string, venue: Partial<InsertVenue>): Promise<Venue>;
  searchVenues(criteria: {
    eventDate?: Date;
    guestCount?: number;
    eventType?: string;
    culturalRequirements?: any;
  }): Promise<Venue[]>;

  // Booking operations
  getBookings(userId?: string): Promise<Booking[]>;
  getBooking(id: string): Promise<Booking | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: string, booking: Partial<InsertBooking>): Promise<Booking>;
  getBookingsByVenue(venueId: string): Promise<Booking[]>;
  checkAvailability(venueId: string, eventDate: Date): Promise<boolean>;

  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPaymentsByBooking(bookingId: string): Promise<Payment[]>;
  updatePaymentStatus(id: string, status: string): Promise<Payment>;

  // Review operations
  createReview(review: InsertReview): Promise<Review>;
  getReviewsByVenue(venueId: string): Promise<Review[]>;
  getApprovedReviews(): Promise<Review[]>;

  // Package operations
  getPackages(): Promise<Package[]>;
  getActivePackages(): Promise<Package[]>;

  // Analytics operations
  getBookingStats(): Promise<{
    totalBookings: number;
    todayBookings: number;
    monthlyRevenue: number;
    activeVenues: number;
    totalCustomers: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, stripeData: { customerId: string; subscriptionId: string }): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId: stripeData.customerId,
        stripeSubscriptionId: stripeData.subscriptionId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Venue operations
  async getVenues(): Promise<Venue[]> {
    return await db.select().from(venues).where(eq(venues.isActive, true)).orderBy(asc(venues.name));
  }

  async getVenue(id: string): Promise<Venue | undefined> {
    const [venue] = await db.select().from(venues).where(eq(venues.id, id));
    return venue;
  }

  async createVenue(venue: InsertVenue): Promise<Venue> {
    const [newVenue] = await db.insert(venues).values(venue).returning();
    return newVenue;
  }

  async updateVenue(id: string, venue: Partial<InsertVenue>): Promise<Venue> {
    const [updatedVenue] = await db
      .update(venues)
      .set({ ...venue, updatedAt: new Date() })
      .where(eq(venues.id, id))
      .returning();
    return updatedVenue;
  }

  async searchVenues(criteria: {
    eventDate?: Date;
    guestCount?: number;
    eventType?: string;
    culturalRequirements?: any;
  }): Promise<Venue[]> {
    let query = db.select().from(venues).where(eq(venues.isActive, true));

    // Filter by capacity if guest count provided
    if (criteria.guestCount) {
      query = query.where(
        sql`CAST((${venues.capacity}->>'sitting')::int AS INTEGER) >= ${criteria.guestCount}`
      );
    }

    return await query.orderBy(asc(venues.name));
  }

  // Booking operations
  async getBookings(userId?: string): Promise<Booking[]> {
    if (userId) {
      return await db.select().from(bookings).where(eq(bookings.customerId, userId)).orderBy(desc(bookings.createdAt));
    }
    return await db.select().from(bookings).orderBy(desc(bookings.createdAt));
  }

  async getBooking(id: string): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking;
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [newBooking] = await db.insert(bookings).values(booking).returning();
    return newBooking;
  }

  async updateBooking(id: string, booking: Partial<InsertBooking>): Promise<Booking> {
    const [updatedBooking] = await db
      .update(bookings)
      .set({ ...booking, updatedAt: new Date() })
      .where(eq(bookings.id, id))
      .returning();
    return updatedBooking;
  }

  async getBookingsByVenue(venueId: string): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.venueId, venueId));
  }

  async checkAvailability(venueId: string, eventDate: Date): Promise<boolean> {
    const existingBookings = await db
      .select()
      .from(bookings)
      .where(
        and(
          eq(bookings.venueId, venueId),
          eq(bookings.eventDate, eventDate),
          eq(bookings.bookingStatus, "confirmed")
        )
      );
    return existingBookings.length === 0;
  }

  // Payment operations
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [newPayment] = await db.insert(payments).values(payment).returning();
    return newPayment;
  }

  async getPaymentsByBooking(bookingId: string): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.bookingId, bookingId));
  }

  async updatePaymentStatus(id: string, status: string): Promise<Payment> {
    const [updatedPayment] = await db
      .update(payments)
      .set({ status })
      .where(eq(payments.id, id))
      .returning();
    return updatedPayment;
  }

  // Review operations
  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    return newReview;
  }

  async getReviewsByVenue(venueId: string): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.venueId, venueId));
  }

  async getApprovedReviews(): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.isApproved, true)).orderBy(desc(reviews.createdAt));
  }

  // Package operations
  async getPackages(): Promise<Package[]> {
    return await db.select().from(packages);
  }

  async getActivePackages(): Promise<Package[]> {
    return await db.select().from(packages).where(eq(packages.isActive, true));
  }

  // Analytics operations
  async getBookingStats(): Promise<{
    totalBookings: number;
    todayBookings: number;
    monthlyRevenue: number;
    activeVenues: number;
    totalCustomers: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

    const [
      totalBookingsResult,
      todayBookingsResult,
      monthlyRevenueResult,
      activeVenuesResult,
      totalCustomersResult
    ] = await Promise.all([
      db.select({ count: sql<number>`count(*)` }).from(bookings),
      db.select({ count: sql<number>`count(*)` }).from(bookings).where(gte(bookings.createdAt, today)),
      db.select({ sum: sql<number>`COALESCE(sum(CAST(total_amount AS DECIMAL)), 0)` }).from(bookings).where(gte(bookings.createdAt, monthStart)),
      db.select({ count: sql<number>`count(*)` }).from(venues).where(eq(venues.isActive, true)),
      db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "customer"))
    ]);

    return {
      totalBookings: totalBookingsResult[0]?.count || 0,
      todayBookings: todayBookingsResult[0]?.count || 0,
      monthlyRevenue: monthlyRevenueResult[0]?.sum || 0,
      activeVenues: activeVenuesResult[0]?.count || 0,
      totalCustomers: totalCustomersResult[0]?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
