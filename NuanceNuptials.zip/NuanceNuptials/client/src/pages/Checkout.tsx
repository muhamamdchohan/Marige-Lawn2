import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { 
  Calendar, 
  Users, 
  MapPin, 
  CreditCard, 
  CheckCircle, 
  ArrowLeft,
  Clock,
  Shield,
  Banknote
} from "lucide-react";
import { Link } from "wouter";
import type { Booking, Venue } from "@shared/schema";

// Load Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || '');

const CheckoutForm = ({ booking, venue }: { booking: Booking; venue: Venue }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/dashboard?payment=success`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Thank you for your payment! Your booking is confirmed.",
      });
      setLocation('/dashboard?payment=success');
    }

    setIsProcessing(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="p-4 bg-muted/30 rounded-lg">
        <h4 className="font-semibold text-foreground mb-2 flex items-center">
          <Shield className="w-5 h-5 mr-2 text-primary" />
          Secure Payment
        </h4>
        <p className="text-sm text-muted-foreground">
          Your payment information is encrypted and secure. We accept all major credit cards.
        </p>
      </div>

      <PaymentElement />

      <Button 
        type="submit" 
        disabled={!stripe || isProcessing}
        className="w-full gradient-primary text-primary-foreground py-3 text-lg"
        data-testid="button-complete-payment"
      >
        {isProcessing ? (
          <div className="flex items-center">
            <div className="loading-spinner w-4 h-4 mr-2"></div>
            Processing Payment...
          </div>
        ) : (
          <div className="flex items-center">
            <CreditCard className="w-5 h-5 mr-2" />
            Pay ₨{Number(booking.remainingAmount || booking.totalAmount).toLocaleString()}
          </div>
        )}
      </Button>

      <div className="text-center text-xs text-muted-foreground">
        <p>By completing this payment, you agree to our terms and conditions.</p>
        <p className="mt-1">Your booking will be confirmed immediately after payment.</p>
      </div>
    </form>
  );
};

export default function Checkout() {
  const params = useParams<{ bookingId: string }>();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [clientSecret, setClientSecret] = useState("");

  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please login to complete payment",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 1000);
    }
  }, [isAuthenticated, toast]);

  const { data: booking, isLoading: bookingLoading } = useQuery<Booking>({
    queryKey: [`/api/bookings/${params.bookingId}`],
    enabled: !!params.bookingId && isAuthenticated,
  });

  const { data: venue, isLoading: venueLoading } = useQuery<Venue>({
    queryKey: [`/api/venues/${booking?.venueId}`],
    enabled: !!booking?.venueId,
  });

  const paymentIntentMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/create-payment-intent', {
        bookingId: params.bookingId
      });
      return response.json();
    },
    onSuccess: (data) => {
      setClientSecret(data.clientSecret);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "Please login again to continue",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 1000);
        return;
      }
      toast({
        title: "Payment Setup Failed",
        description: "Failed to setup payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (booking && booking.paymentStatus !== 'complete') {
      paymentIntentMutation.mutate();
    }
  }, [booking]);

  const getEventTypeLabel = (eventType: string) => {
    const labels = {
      mehndi: 'Mehndi Ceremony',
      nikah: 'Nikah Ceremony',
      walima: 'Walima Reception',
      reception: 'Reception'
    };
    return labels[eventType as keyof typeof labels] || eventType;
  };

  const getEventTypeEmoji = (eventType: string) => {
    const emojis = {
      mehndi: '🤲',
      nikah: '🕌',
      walima: '🍽️',
      reception: '🥂'
    };
    return emojis[eventType as keyof typeof emojis] || '💒';
  };

  if (!isAuthenticated) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="loading-spinner w-8 h-8"></div>
        </div>
      </Layout>
    );
  }

  if (bookingLoading || venueLoading) {
    return (
      <Layout>
        <div className="min-h-screen bg-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="animate-pulse space-y-6">
              <div className="h-8 bg-muted rounded w-1/3"></div>
              <div className="h-64 bg-muted rounded"></div>
              <div className="h-48 bg-muted rounded"></div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!booking) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-foreground mb-4">Booking Not Found</h2>
            <p className="text-muted-foreground mb-6">The requested booking could not be found.</p>
            <Button asChild>
              <Link href="/dashboard">Back to Dashboard</Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  if (booking.paymentStatus === 'complete') {
    return (
      <Layout>
        <div className="min-h-screen bg-background" data-testid="checkout-complete">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="text-center">
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
              <h1 className="text-3xl font-serif font-bold text-foreground mb-2">
                Payment Complete!
              </h1>
              <p className="text-lg text-muted-foreground mb-6">
                Your booking has been confirmed and payment is complete.
              </p>
              <div className="space-x-4">
                <Button asChild>
                  <Link href="/dashboard">View Bookings</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link href="/venues">Book Another Event</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!clientSecret) {
    return (
      <Layout>
        <div className="min-h-screen bg-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex items-center justify-center">
              <div className="text-center">
                <div className="loading-spinner w-8 h-8 mx-auto mb-4"></div>
                <p>Setting up payment...</p>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-background" data-testid="checkout-page">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <Button variant="ghost" asChild className="mb-4" data-testid="button-back-to-dashboard">
              <Link href="/dashboard">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <h1 className="text-3xl lg:text-4xl font-serif font-bold text-foreground mb-2">
              Complete Your Payment
            </h1>
            <p className="text-lg text-muted-foreground font-urdu">
              آپ کی ادائیگی مکمل کریں
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Booking Summary */}
            <div className="space-y-6">
              <Card className="wedding-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="w-5 h-5 mr-2 text-primary" />
                    Booking Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xl font-serif font-bold text-foreground">
                        {getEventTypeEmoji(booking.eventType)} {getEventTypeLabel(booking.eventType)}
                      </h3>
                      <Badge className="bg-primary/10 text-primary">
                        {booking.bookingStatus}
                      </Badge>
                    </div>

                    {venue && (
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <h4 className="font-semibold text-foreground mb-2">{venue.name}</h4>
                        {venue.location && (
                          <div className="flex items-center text-sm text-muted-foreground">
                            <MapPin className="w-4 h-4 mr-2" />
                            <span>{venue.location.address}, {venue.location.city}</span>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center">
                        <Calendar className="w-5 h-5 text-primary mr-2" />
                        <div>
                          <div className="font-medium">Event Date</div>
                          <div className="text-sm text-muted-foreground">
                            {new Date(booking.eventDate).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center">
                        <Users className="w-5 h-5 text-primary mr-2" />
                        <div>
                          <div className="font-medium">Guests</div>
                          <div className="text-sm text-muted-foreground">
                            {booking.guestCount} people
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center">
                        <Clock className="w-5 h-5 text-primary mr-2" />
                        <div>
                          <div className="font-medium">Event Time</div>
                          <div className="text-sm text-muted-foreground">
                            {booking.eventTime?.start} - {booking.eventTime?.end}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center">
                        <CreditCard className="w-5 h-5 text-primary mr-2" />
                        <div>
                          <div className="font-medium">Payment Status</div>
                          <div className="text-sm text-muted-foreground">
                            {booking.paymentStatus}
                          </div>
                        </div>
                      </div>
                    </div>

                    {booking.specialRequests && (
                      <div className="p-3 bg-muted/30 rounded">
                        <h5 className="font-medium text-foreground mb-1">Special Requests</h5>
                        <p className="text-sm text-muted-foreground">{booking.specialRequests}</p>
                      </div>
                    )}

                    {/* Cultural Requirements */}
                    {booking.culturalRequirements && (
                      <div className="p-3 bg-primary/5 rounded">
                        <h5 className="font-medium text-foreground mb-2">Cultural Requirements</h5>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          {booking.culturalRequirements.halalFood && (
                            <div className="flex items-center text-primary">
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Halal Food
                            </div>
                          )}
                          {booking.culturalRequirements.prayerArrangements && (
                            <div className="flex items-center text-primary">
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Prayer Arrangements
                            </div>
                          )}
                          {booking.culturalRequirements.segregatedSeating && (
                            <div className="flex items-center text-primary">
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Segregated Seating
                            </div>
                          )}
                          {booking.culturalRequirements.islamicDecor && (
                            <div className="flex items-center text-primary">
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Islamic Decorations
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Islamic Blessing */}
              <Card className="bg-gradient-to-br from-accent/10 to-accent/5 border-accent/20">
                <CardContent className="pt-6">
                  <blockquote className="text-center">
                    <p className="font-urdu text-lg text-foreground mb-2">
                      "بارک اللہ لکما و بارک علیکما و جمع بینکما فی خیر"
                    </p>
                    <p className="text-sm text-muted-foreground italic">
                      "May Allah bless you both and unite you in goodness"
                    </p>
                    <footer className="text-xs text-muted-foreground mt-2">
                      - Wedding Prayer
                    </footer>
                  </blockquote>
                </CardContent>
              </Card>
            </div>

            {/* Payment Form */}
            <div>
              <Card className="booking-form">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Banknote className="w-5 h-5 mr-2 text-primary" />
                    Payment Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Payment Breakdown */}
                  <div className="bg-muted/30 p-4 rounded-lg mb-6">
                    <h4 className="font-semibold text-foreground mb-3">Payment Breakdown</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Total Event Cost</span>
                        <span>₨{Number(booking.totalAmount).toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Already Paid (Advance)</span>
                        <span>₨{Number(booking.advancePayment || 0).toLocaleString()}</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between font-bold text-primary">
                        <span>Amount Due</span>
                        <span>₨{Number(booking.remainingAmount || booking.totalAmount).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Stripe Payment Form */}
                  <Elements stripe={stripePromise} options={{ clientSecret }}>
                    <CheckoutForm booking={booking} venue={venue!} />
                  </Elements>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
