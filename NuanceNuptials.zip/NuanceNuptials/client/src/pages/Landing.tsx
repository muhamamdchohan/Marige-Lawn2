import Layout from "@/components/Layout";
import HeroSection from "@/components/HeroSection";
import FeaturedVenues from "@/components/FeaturedVenues";
import ServicesSection from "@/components/ServicesSection";
import TestimonialsSection from "@/components/TestimonialsSection";

export default function Landing() {
  return (
    <Layout>
      <div data-testid="landing-page">
        <HeroSection />
        <FeaturedVenues />
        <ServicesSection />
        <TestimonialsSection />
      </div>
    </Layout>
  );
}
