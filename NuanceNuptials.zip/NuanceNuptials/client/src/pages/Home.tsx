import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { Calendar, Building, Heart, Star, Clock, MapPin } from "lucide-react";
import type { Booking } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();

  const { data: bookings, isLoading } = useQuery<Booking[]>({
    queryKey: ['/api/bookings'],
  });

  const upcomingBookings = bookings?.filter(booking => 
    new Date(booking.eventDate) > new Date() && 
    booking.bookingStatus === 'confirmed'
  ).slice(0, 3) || [];

  const getEventTypeLabel = (eventType: string) => {
    const labels = {
      mehndi: 'Mehndi Ceremony',
      nikah: 'Nikah Ceremony', 
      walima: 'Walima Reception',
      reception: 'Reception'
    };
    return labels[eventType as keyof typeof labels] || eventType;
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 islamic-pattern" data-testid="home-page">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Welcome Header */}
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-serif font-bold text-foreground mb-2">
              Welcome back, {user?.firstName || 'Valued Customer'}!
            </h1>
            <p className="text-lg text-muted-foreground font-urdu">
              خوش آمدید - آپ کے خوشی کے لمحات کا انتظار
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Quick Actions */}
            <div className="lg:col-span-2 space-y-6">
              <Card className="wedding-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="w-5 h-5 mr-2 text-primary" />
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    <Button asChild className="h-20 flex-col bg-primary/5 hover:bg-primary/10 text-primary border-2 border-primary/20" data-testid="button-new-booking">
                      <Link href="/venues">
                        <Building className="w-6 h-6 mb-2" />
                        <span>Book New Venue</span>
                        <span className="text-xs opacity-70">Find perfect halls</span>
                      </Link>
                    </Button>
                    <Button asChild className="h-20 flex-col bg-accent/5 hover:bg-accent/10 text-accent border-2 border-accent/20" data-testid="button-view-bookings">
                      <Link href="/dashboard">
                        <Heart className="w-6 h-6 mb-2" />
                        <span>My Bookings</span>
                        <span className="text-xs opacity-70">Manage events</span>
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Upcoming Events */}
              <Card className="wedding-card">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Star className="w-5 h-5 mr-2 text-primary" />
                      Upcoming Celebrations
                    </div>
                    <Button asChild variant="outline" size="sm">
                      <Link href="/dashboard">View All</Link>
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="animate-pulse">
                          <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                          <div className="h-3 bg-muted rounded w-1/2"></div>
                        </div>
                      ))}
                    </div>
                  ) : upcomingBookings.length > 0 ? (
                    <div className="space-y-4">
                      {upcomingBookings.map((booking) => (
                        <div key={booking.id} className="border-l-4 border-primary pl-4 py-2" data-testid={`upcoming-booking-${booking.id}`}>
                          <h4 className="font-semibold text-foreground">
                            {getEventTypeLabel(booking.eventType)}
                          </h4>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <Calendar className="w-4 h-4 mr-1" />
                            <span>{new Date(booking.eventDate).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long', 
                              day: 'numeric'
                            })}</span>
                          </div>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <MapPin className="w-4 h-4 mr-1" />
                            <span>{booking.guestCount} guests</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No upcoming events</p>
                      <p className="text-sm text-muted-foreground mb-4">Start planning your perfect celebration</p>
                      <Button asChild>
                        <Link href="/venues">Browse Venues</Link>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar - Cultural Info & Prayer Times */}
            <div className="space-y-6">
              {/* Prayer Times */}
              <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-primary">
                    <Clock className="w-5 h-5 mr-2" />
                    Prayer Times
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Fajr</span>
                    <span className="font-medium">5:30 AM</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Zuhr</span>
                    <span className="font-medium">12:15 PM</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Asr</span>
                    <span className="font-medium">3:45 PM</span>
                  </div>
                  <div className="flex justify-between text-sm bg-primary/10 p-2 rounded">
                    <span className="font-semibold">Maghrib</span>
                    <span className="font-bold text-primary">6:30 PM</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Isha</span>
                    <span className="font-medium">8:00 PM</span>
                  </div>
                </CardContent>
              </Card>

              {/* Cultural Quote */}
              <Card className="bg-gradient-to-br from-accent/10 to-accent/5 border-accent/20">
                <CardContent className="pt-6">
                  <blockquote className="text-center">
                    <p className="font-urdu text-lg text-foreground mb-2">
                      "اور اس کی نشانیوں میں سے یہ ہے کہ اس نے تمہارے لیے تمہاری ہی جنس سے جوڑے بنائے"
                    </p>
                    <p className="text-sm text-muted-foreground italic">
                      "And among His signs is that He created for you mates from among yourselves"
                    </p>
                    <footer className="text-xs text-muted-foreground mt-2">
                      - Surah Ar-Rum (30:21)
                    </footer>
                  </blockquote>
                </CardContent>
              </Card>

              {/* Support */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">Need Help?</CardTitle>
                </CardHeader>
                <CardContent className="text-center space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Our team is here to help you plan the perfect celebration
                  </p>
                  <div className="space-y-2 text-sm">
                    <div>📞 +92 321 1234567</div>
                    <div>📧 info@shaadipalace.pk</div>
                    <div>💬 24/7 WhatsApp Support</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
