import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Calendar, 
  Users, 
  Building, 
  TrendingUp, 
  DollarSign,
  CheckCircle,
  Clock,
  XCircle,
  AlertCircle,
  Star,
  MapPin
} from "lucide-react";
import { useEffect } from "react";
import type { Booking, Venue } from "@shared/schema";

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Unauthorized", 
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }

    if (user && user.role !== 'admin') {
      toast({
        title: "Access Denied",
        description: "You don't have admin privileges",
        variant: "destructive",
      });
      return;
    }
  }, [isAuthenticated, user, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/analytics/stats'],
    retry: false,
  });

  const { data: bookings, isLoading: bookingsLoading } = useQuery<Booking[]>({
    queryKey: ['/api/bookings'],
    retry: false,
  });

  const { data: venues, isLoading: venuesLoading } = useQuery<Venue[]>({
    queryKey: ['/api/venues'],
    retry: false,
  });

  if (!isAuthenticated || (user && user.role !== 'admin')) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <AlertCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-foreground mb-2">Access Denied</h2>
            <p className="text-muted-foreground">You don't have permission to access this page.</p>
          </div>
        </div>
      </Layout>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'completed':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="w-4 h-4" />;
      case 'pending':
        return <Clock className="w-4 h-4" />;
      case 'cancelled':
        return <XCircle className="w-4 h-4" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <AlertCircle className="w-4 h-4" />;
    }
  };

  const getEventTypeLabel = (eventType: string) => {
    const labels = {
      mehndi: 'Mehndi Ceremony',
      nikah: 'Nikah Ceremony',
      walima: 'Walima Reception', 
      reception: 'Reception'
    };
    return labels[eventType as keyof typeof labels] || eventType;
  };

  const recentBookings = bookings?.slice(0, 5) || [];
  const todaysBookings = bookings?.filter(booking => {
    const today = new Date();
    const bookingDate = new Date(booking.eventDate);
    return bookingDate.toDateString() === today.toDateString();
  }) || [];

  return (
    <Layout>
      <div className="min-h-screen bg-background" data-testid="admin-dashboard-page">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-serif font-bold text-foreground mb-2">
              Admin Dashboard
            </h1>
            <p className="text-lg text-muted-foreground">
              Comprehensive business management and analytics
            </p>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="admin-stats-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Today's Bookings</p>
                    <p className="text-2xl font-bold text-primary" data-testid="stat-today-bookings">
                      {statsLoading ? '...' : (stats?.todayBookings || todaysBookings.length)}
                    </p>
                  </div>
                  <Calendar className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card className="admin-stats-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Monthly Revenue</p>
                    <p className="text-2xl font-bold text-accent" data-testid="stat-monthly-revenue">
                      {statsLoading ? '...' : `₨${(stats?.monthlyRevenue || 0).toLocaleString()}`}
                    </p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-accent" />
                </div>
              </CardContent>
            </Card>

            <Card className="admin-stats-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Active Venues</p>
                    <p className="text-2xl font-bold text-secondary" data-testid="stat-active-venues">
                      {statsLoading ? '...' : (stats?.activeVenues || venues?.length || 0)}
                    </p>
                  </div>
                  <Building className="w-8 h-8 text-secondary" />
                </div>
              </CardContent>
            </Card>

            <Card className="admin-stats-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Customers</p>
                    <p className="text-2xl font-bold text-primary" data-testid="stat-total-customers">
                      {statsLoading ? '...' : (stats?.totalCustomers || 0)}
                    </p>
                  </div>
                  <Users className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Dashboard Tabs */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="bookings">Bookings</TabsTrigger>
              <TabsTrigger value="venues">Venues</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Recent Bookings */}
                <Card className="wedding-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Calendar className="w-5 h-5 mr-2 text-primary" />
                      Recent Bookings
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {bookingsLoading ? (
                      <div className="space-y-4">
                        {[1, 2, 3].map(i => (
                          <div key={i} className="animate-pulse border rounded-lg p-4">
                            <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                            <div className="h-3 bg-muted rounded w-1/2"></div>
                          </div>
                        ))}
                      </div>
                    ) : recentBookings.length > 0 ? (
                      <div className="space-y-4">
                        {recentBookings.map((booking) => (
                          <div key={booking.id} className="border rounded-lg p-4" data-testid={`recent-booking-${booking.id}`}>
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-semibold text-foreground">
                                {getEventTypeLabel(booking.eventType)}
                              </h4>
                              <Badge className={getStatusColor(booking.bookingStatus)}>
                                {getStatusIcon(booking.bookingStatus)}
                                <span className="ml-1 capitalize">{booking.bookingStatus}</span>
                              </Badge>
                            </div>
                            <div className="text-sm text-muted-foreground space-y-1">
                              <div className="flex items-center">
                                <Calendar className="w-4 h-4 mr-2" />
                                <span>{new Date(booking.eventDate).toLocaleDateString()}</span>
                              </div>
                              <div className="flex items-center">
                                <Users className="w-4 h-4 mr-2" />
                                <span>{booking.guestCount} guests</span>
                              </div>
                              <div className="flex items-center">
                                <DollarSign className="w-4 h-4 mr-2" />
                                <span>₨{Number(booking.totalAmount).toLocaleString()}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                        <p className="text-muted-foreground">No recent bookings</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <Button className="h-20 flex-col bg-primary/5 hover:bg-primary/10 text-primary border-2 border-primary/20" data-testid="button-new-booking">
                        <Calendar className="w-6 h-6 mb-2" />
                        <span>New Booking</span>
                      </Button>
                      <Button className="h-20 flex-col bg-accent/5 hover:bg-accent/10 text-accent border-2 border-accent/20" data-testid="button-manage-venues">
                        <Building className="w-6 h-6 mb-2" />
                        <span>Manage Venues</span>
                      </Button>
                      <Button className="h-20 flex-col bg-secondary/5 hover:bg-secondary/10 text-secondary border-2 border-secondary/20" data-testid="button-view-reports">
                        <TrendingUp className="w-6 h-6 mb-2" />
                        <span>View Reports</span>
                      </Button>
                      <Button className="h-20 flex-col bg-primary/5 hover:bg-primary/10 text-primary border-2 border-primary/20" data-testid="button-customer-support">
                        <Users className="w-6 h-6 mb-2" />
                        <span>Customer Support</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity Feed */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentBookings.slice(0, 5).map((booking, index) => (
                      <div key={booking.id} className="flex items-center p-3 bg-muted/30 rounded-lg">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                          booking.bookingStatus === 'confirmed' ? 'bg-primary' : 
                          booking.bookingStatus === 'pending' ? 'bg-accent' : 'bg-secondary'
                        }`}>
                          {getStatusIcon(booking.bookingStatus)}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-foreground">
                            {booking.bookingStatus === 'confirmed' ? 'New booking confirmed' :
                             booking.bookingStatus === 'pending' ? 'Booking request received' :
                             'Booking status updated'}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {getEventTypeLabel(booking.eventType)} - {new Date(booking.eventDate).toLocaleDateString()}
                          </p>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {new Date(booking.createdAt!).toLocaleDateString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Bookings Tab */}
            <TabsContent value="bookings" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>All Bookings</CardTitle>
                </CardHeader>
                <CardContent>
                  {bookingsLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3, 4, 5].map(i => (
                        <div key={i} className="animate-pulse border rounded-lg p-4">
                          <div className="h-6 bg-muted rounded w-3/4 mb-2"></div>
                          <div className="h-4 bg-muted rounded w-1/2 mb-2"></div>
                          <div className="h-4 bg-muted rounded w-2/3"></div>
                        </div>
                      ))}
                    </div>
                  ) : bookings && bookings.length > 0 ? (
                    <div className="space-y-4">
                      {bookings.map((booking) => (
                        <div key={booking.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow" data-testid={`admin-booking-${booking.id}`}>
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold text-foreground">
                              {getEventTypeLabel(booking.eventType)}
                            </h4>
                            <div className="flex items-center space-x-2">
                              <Badge className={getStatusColor(booking.bookingStatus)}>
                                {getStatusIcon(booking.bookingStatus)}
                                <span className="ml-1 capitalize">{booking.bookingStatus}</span>
                              </Badge>
                            </div>
                          </div>
                          
                          <div className="grid md:grid-cols-3 gap-4 text-sm text-muted-foreground">
                            <div className="space-y-1">
                              <div className="flex items-center">
                                <Calendar className="w-4 h-4 mr-2" />
                                <span>{new Date(booking.eventDate).toLocaleDateString()}</span>
                              </div>
                              <div className="flex items-center">
                                <Users className="w-4 h-4 mr-2" />
                                <span>{booking.guestCount} guests</span>
                              </div>
                            </div>
                            <div className="space-y-1">
                              <div className="flex items-center">
                                <DollarSign className="w-4 h-4 mr-2" />
                                <span>₨{Number(booking.totalAmount).toLocaleString()}</span>
                              </div>
                              <div className="flex items-center">
                                <span className="text-xs">Payment: {booking.paymentStatus}</span>
                              </div>
                            </div>
                            <div className="space-y-1">
                              <div className="flex items-center">
                                <Clock className="w-4 h-4 mr-2" />
                                <span>Booked: {new Date(booking.createdAt!).toLocaleDateString()}</span>
                              </div>
                            </div>
                          </div>

                          {booking.specialRequests && (
                            <div className="mt-3 p-2 bg-muted/30 rounded text-sm">
                              <strong>Special Requests:</strong> {booking.specialRequests}
                            </div>
                          )}

                          <div className="mt-3 flex justify-end space-x-2">
                            <Button variant="outline" size="sm">View Details</Button>
                            <Button variant="outline" size="sm">Contact Customer</Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No bookings found</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Venues Tab */}
            <TabsContent value="venues" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Venue Management</span>
                    <Button>Add New Venue</Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {venuesLoading ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="animate-pulse border rounded-lg p-4">
                          <div className="h-32 bg-muted rounded mb-4"></div>
                          <div className="h-6 bg-muted rounded w-3/4 mb-2"></div>
                          <div className="h-4 bg-muted rounded w-1/2"></div>
                        </div>
                      ))}
                    </div>
                  ) : venues && venues.length > 0 ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {venues.map((venue) => (
                        <div key={venue.id} className="venue-card border rounded-lg overflow-hidden" data-testid={`admin-venue-${venue.id}`}>
                          {venue.images && venue.images.length > 0 ? (
                            <img 
                              src={venue.images[0]} 
                              alt={venue.name}
                              className="w-full h-32 object-cover"
                            />
                          ) : (
                            <div className="w-full h-32 bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center">
                              <Building className="w-8 h-8 text-primary/50" />
                            </div>
                          )}
                          
                          <div className="p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-semibold text-foreground">{venue.name}</h4>
                              <div className="flex items-center text-accent">
                                <Star className="w-4 h-4 fill-current" />
                                <span className="ml-1 text-sm">{venue.rating || '4.8'}</span>
                              </div>
                            </div>
                            
                            {venue.location && (
                              <div className="flex items-center text-sm text-muted-foreground mb-2">
                                <MapPin className="w-4 h-4 mr-1" />
                                <span>{venue.location.city}</span>
                              </div>
                            )}
                            
                            <div className="flex items-center text-sm text-muted-foreground mb-3">
                              <Users className="w-4 h-4 mr-2" />
                              <span>Up to {venue.capacity?.sitting || 500} guests</span>
                            </div>

                            <div className="flex justify-between items-center">
                              <span className="text-lg font-bold text-primary">
                                ₨{venue.pricing?.baseRate ? Number(venue.pricing.baseRate).toLocaleString() : '150,000'}
                              </span>
                              <div className="space-x-2">
                                <Button variant="outline" size="sm">Edit</Button>
                                <Button variant="outline" size="sm">
                                  {venue.isActive ? 'Active' : 'Inactive'}
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Building className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No venues found</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Revenue Analytics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center p-4 bg-muted/30 rounded-lg">
                        <span className="font-medium">Total Bookings</span>
                        <span className="text-2xl font-bold text-primary">{bookings?.length || 0}</span>
                      </div>
                      <div className="flex justify-between items-center p-4 bg-muted/30 rounded-lg">
                        <span className="font-medium">Total Revenue</span>
                        <span className="text-2xl font-bold text-accent">
                          ₨{(bookings?.reduce((sum, booking) => sum + (Number(booking.totalAmount) || 0), 0) || 0).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-4 bg-muted/30 rounded-lg">
                        <span className="font-medium">Average Booking Value</span>
                        <span className="text-2xl font-bold text-secondary">
                          ₨{bookings?.length ? Math.round((bookings.reduce((sum, booking) => sum + (Number(booking.totalAmount) || 0), 0) / bookings.length)).toLocaleString() : '0'}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Event Type Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {bookings && bookings.length > 0 ? (
                      <div className="space-y-4">
                        {['mehndi', 'nikah', 'walima', 'reception'].map((eventType) => {
                          const count = bookings.filter(b => b.eventType === eventType).length;
                          const percentage = bookings.length > 0 ? (count / bookings.length) * 100 : 0;
                          
                          return (
                            <div key={eventType} className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="capitalize">{getEventTypeLabel(eventType)}</span>
                                <span>{count} ({percentage.toFixed(1)}%)</span>
                              </div>
                              <div className="w-full bg-muted h-2 rounded-full">
                                <div 
                                  className="bg-primary h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${percentage}%` }}
                                ></div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="text-muted-foreground text-center py-8">No data available</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
}
