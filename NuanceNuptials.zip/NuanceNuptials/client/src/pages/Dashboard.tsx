import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  CreditCard, 
  CheckCircle, 
  AlertCircle,
  XCircle,
  Eye
} from "lucide-react";
import { Link } from "wouter";
import { useEffect } from "react";
import type { Booking, Venue } from "@shared/schema";

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, toast]);

  const { data: bookings, isLoading } = useQuery<Booking[]>({
    queryKey: ['/api/bookings'],
    retry: false,
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'completed':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'complete':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'partial':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'pending':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="w-4 h-4" />;
      case 'pending':
        return <Clock className="w-4 h-4" />;
      case 'cancelled':
        return <XCircle className="w-4 h-4" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <AlertCircle className="w-4 h-4" />;
    }
  };

  const getEventTypeLabel = (eventType: string) => {
    const labels = {
      mehndi: 'Mehndi Ceremony',
      nikah: 'Nikah Ceremony',
      walima: 'Walima Reception',
      reception: 'Reception'
    };
    return labels[eventType as keyof typeof labels] || eventType;
  };

  const upcomingBookings = bookings?.filter(booking => 
    new Date(booking.eventDate) > new Date()
  ).sort((a, b) => new Date(a.eventDate).getTime() - new Date(b.eventDate).getTime()) || [];

  const pastBookings = bookings?.filter(booking => 
    new Date(booking.eventDate) <= new Date()
  ).sort((a, b) => new Date(b.eventDate).getTime() - new Date(a.eventDate).getTime()) || [];

  const stats = {
    totalBookings: bookings?.length || 0,
    upcomingEvents: upcomingBookings.length,
    completedEvents: pastBookings.filter(b => b.bookingStatus === 'completed').length,
    totalSpent: bookings?.reduce((sum, booking) => sum + (Number(booking.totalAmount) || 0), 0) || 0
  };

  if (!isAuthenticated) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="loading-spinner w-8 h-8"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-background" data-testid="dashboard-page">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-serif font-bold text-foreground mb-2">
              My Dashboard
            </h1>
            <p className="text-lg text-muted-foreground font-urdu">
              آپ کی بکنگز کا جائزہ
            </p>
            <p className="text-lg text-muted-foreground">
              Manage your wedding bookings and celebrations
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="admin-stats-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Bookings</p>
                    <p className="text-2xl font-bold text-primary" data-testid="stat-total-bookings">
                      {stats.totalBookings}
                    </p>
                  </div>
                  <Calendar className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card className="admin-stats-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Upcoming Events</p>
                    <p className="text-2xl font-bold text-accent" data-testid="stat-upcoming-events">
                      {stats.upcomingEvents}
                    </p>
                  </div>
                  <Clock className="w-8 h-8 text-accent" />
                </div>
              </CardContent>
            </Card>

            <Card className="admin-stats-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Completed</p>
                    <p className="text-2xl font-bold text-green-600" data-testid="stat-completed-events">
                      {stats.completedEvents}
                    </p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="admin-stats-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Spent</p>
                    <p className="text-2xl font-bold text-secondary" data-testid="stat-total-spent">
                      ₨{stats.totalSpent.toLocaleString()}
                    </p>
                  </div>
                  <CreditCard className="w-8 h-8 text-secondary" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Upcoming Bookings */}
            <Card className="wedding-card">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Calendar className="w-5 h-5 mr-2 text-primary" />
                    Upcoming Events
                  </div>
                  <Button asChild variant="outline" size="sm">
                    <Link href="/venues">Book New Event</Link>
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="animate-pulse border rounded-lg p-4">
                        <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-muted rounded w-1/2 mb-2"></div>
                        <div className="h-3 bg-muted rounded w-2/3"></div>
                      </div>
                    ))}
                  </div>
                ) : upcomingBookings.length > 0 ? (
                  <div className="space-y-4">
                    {upcomingBookings.slice(0, 3).map((booking) => (
                      <div key={booking.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow" data-testid={`upcoming-booking-${booking.id}`}>
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-foreground">
                            {getEventTypeLabel(booking.eventType)}
                          </h4>
                          <div className="flex items-center space-x-2">
                            <Badge className={getStatusColor(booking.bookingStatus)}>
                              {getStatusIcon(booking.bookingStatus)}
                              <span className="ml-1 capitalize">{booking.bookingStatus}</span>
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="space-y-2 text-sm text-muted-foreground">
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-2" />
                            <span>{new Date(booking.eventDate).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}</span>
                          </div>
                          <div className="flex items-center">
                            <Users className="w-4 h-4 mr-2" />
                            <span>{booking.guestCount} guests</span>
                          </div>
                          <div className="flex items-center">
                            <CreditCard className="w-4 h-4 mr-2" />
                            <span>₨{Number(booking.totalAmount).toLocaleString()}</span>
                            <Badge className={`ml-2 ${getPaymentStatusColor(booking.paymentStatus)}`}>
                              {booking.paymentStatus}
                            </Badge>
                          </div>
                        </div>

                        {booking.paymentStatus === 'pending' && (
                          <div className="mt-3">
                            <Button asChild size="sm" className="bg-primary text-primary-foreground">
                              <Link href={`/checkout/${booking.id}`}>Complete Payment</Link>
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                    
                    {upcomingBookings.length > 3 && (
                      <div className="text-center pt-4">
                        <Button variant="outline" size="sm">
                          View All Upcoming ({upcomingBookings.length})
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground mb-4">No upcoming events scheduled</p>
                    <Button asChild>
                      <Link href="/venues">Book Your First Event</Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Past Bookings */}
            <Card className="wedding-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2 text-primary" />
                  Event History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {pastBookings.length > 0 ? (
                  <div className="space-y-4">
                    {pastBookings.slice(0, 3).map((booking) => (
                      <div key={booking.id} className="border rounded-lg p-4 opacity-75" data-testid={`past-booking-${booking.id}`}>
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-foreground">
                            {getEventTypeLabel(booking.eventType)}
                          </h4>
                          <Badge className={getStatusColor(booking.bookingStatus)}>
                            {getStatusIcon(booking.bookingStatus)}
                            <span className="ml-1 capitalize">{booking.bookingStatus}</span>
                          </Badge>
                        </div>
                        
                        <div className="space-y-2 text-sm text-muted-foreground">
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-2" />
                            <span>{new Date(booking.eventDate).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}</span>
                          </div>
                          <div className="flex items-center">
                            <Users className="w-4 h-4 mr-2" />
                            <span>{booking.guestCount} guests</span>
                          </div>
                          <div className="flex items-center">
                            <CreditCard className="w-4 h-4 mr-2" />
                            <span>₨{Number(booking.totalAmount).toLocaleString()}</span>
                          </div>
                        </div>

                        {booking.bookingStatus === 'completed' && (
                          <div className="mt-3">
                            <Button variant="outline" size="sm" disabled>
                              <Eye className="w-4 h-4 mr-2" />
                              Leave Review
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                    
                    {pastBookings.length > 3 && (
                      <div className="text-center pt-4">
                        <Button variant="outline" size="sm">
                          View All History ({pastBookings.length})
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <CheckCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">No past events yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <Button asChild className="h-20 flex-col">
                  <Link href="/venues">
                    <Calendar className="w-6 h-6 mb-2" />
                    <span>Book New Venue</span>
                  </Link>
                </Button>
                <Button asChild variant="outline" className="h-20 flex-col">
                  <Link href="/profile">
                    <Users className="w-6 h-6 mb-2" />
                    <span>Update Profile</span>
                  </Link>
                </Button>
                <Button asChild variant="outline" className="h-20 flex-col">
                  <Link href="/support">
                    <AlertCircle className="w-6 h-6 mb-2" />
                    <span>Contact Support</span>
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
