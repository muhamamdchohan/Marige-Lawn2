import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { 
  Calendar, 
  Users, 
  Church, 
  Star, 
  MapPin, 
  Car, 
  Clock,
  CheckCircle,
  ArrowLeft
} from "lucide-react";
import { Link } from "wouter";
import type { Venue, InsertBooking } from "@shared/schema";

export default function BookingForm() {
  const params = useParams<{ venueId: string; id: string }>();
  const [location, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const venueId = params.venueId || params.id;
  const urlParams = new URLSearchParams(location.split('?')[1] || '');

  const [bookingData, setBookingData] = useState({
    eventType: urlParams.get('eventType') || 'mehndi',
    eventDate: urlParams.get('eventDate') || '',
    eventTime: {
      start: '18:00',
      end: '23:00'
    },
    guestCount: parseInt(urlParams.get('guestCount')?.split('-')[0] || '100'),
    specialRequests: '',
    culturalRequirements: {
      prayerArrangements: false,
      halalFood: false,
      segregatedSeating: false,
      islamicDecor: false
    }
  });

  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please login to book a venue",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 1000);
    }
  }, [isAuthenticated, toast]);

  const { data: venue, isLoading: venueLoading } = useQuery<Venue>({
    queryKey: [`/api/venues/${venueId}`],
    enabled: !!venueId,
  });

  const bookingMutation = useMutation({
    mutationFn: async (data: InsertBooking) => {
      const response = await apiRequest('POST', '/api/bookings', data);
      return response.json();
    },
    onSuccess: (booking) => {
      toast({
        title: "Booking Confirmed!",
        description: "Your venue has been successfully booked. You will receive a confirmation email shortly.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      setLocation(`/checkout/${booking.id}`);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "Please login again to continue",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 1000);
        return;
      }
      toast({
        title: "Booking Failed",
        description: error.message || "Failed to create booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!venue || !user) return;

    const totalAmount = calculateTotal();
    
    const booking: InsertBooking = {
      venueId: venue.id,
      eventType: bookingData.eventType as "mehndi" | "nikah" | "walima" | "reception",
      eventDate: new Date(bookingData.eventDate),
      eventTime: bookingData.eventTime,
      guestCount: bookingData.guestCount,
      totalAmount: totalAmount.toString(),
      advancePayment: (totalAmount * 0.3).toString(), // 30% advance
      remainingAmount: (totalAmount * 0.7).toString(),
      specialRequests: bookingData.specialRequests,
      culturalRequirements: bookingData.culturalRequirements,
      paymentStatus: "pending",
      bookingStatus: "pending"
    };

    bookingMutation.mutate(booking);
  };

  const calculateTotal = () => {
    if (!venue?.pricing) return 0;
    
    const baseRate = Number(venue.pricing.baseRate) || 150000;
    const guestMultiplier = Math.ceil(bookingData.guestCount / 100);
    const eventTypeMultiplier = bookingData.eventType === 'walima' ? 1.3 : 
                                bookingData.eventType === 'nikah' ? 1.1 : 1.0;
    
    // Weekend pricing (Friday/Saturday)
    const eventDay = new Date(bookingData.eventDate).getDay();
    const weekendMultiplier = (eventDay === 5 || eventDay === 6) ? 1.2 : 1.0;
    
    return Math.round(baseRate * guestMultiplier * eventTypeMultiplier * weekendMultiplier);
  };

  const getEventTypeEmoji = (eventType: string) => {
    const emojis = {
      mehndi: '🤲',
      nikah: '🕌', 
      walima: '🍽️',
      reception: '🥂'
    };
    return emojis[eventType as keyof typeof emojis] || '💒';
  };

  if (!isAuthenticated) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="loading-spinner w-8 h-8"></div>
        </div>
      </Layout>
    );
  }

  if (venueLoading) {
    return (
      <Layout>
        <div className="min-h-screen bg-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="animate-pulse space-y-6">
              <div className="h-8 bg-muted rounded w-1/3"></div>
              <div className="h-64 bg-muted rounded"></div>
              <div className="h-48 bg-muted rounded"></div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!venue) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-foreground mb-4">Venue Not Found</h2>
            <p className="text-muted-foreground mb-6">The requested venue could not be found.</p>
            <Button asChild>
              <Link href="/venues">Browse Venues</Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-background" data-testid="booking-form-page">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <Button variant="ghost" asChild className="mb-4" data-testid="button-back-to-venues">
              <Link href="/venues">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Venues
              </Link>
            </Button>
            <h1 className="text-3xl lg:text-4xl font-serif font-bold text-foreground mb-2">
              Book Your Celebration
            </h1>
            <p className="text-lg text-muted-foreground font-urdu">
              اپنی خوشی کا دن بک کریں
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Venue Details */}
            <div className="space-y-6">
              <Card className="wedding-card">
                <CardContent className="p-0">
                  {venue.images && venue.images.length > 0 ? (
                    <img 
                      src={venue.images[0]} 
                      alt={venue.name}
                      className="w-full h-64 object-cover rounded-t-lg"
                    />
                  ) : (
                    <div className="w-full h-64 bg-gradient-to-br from-primary/10 to-accent/10 rounded-t-lg flex items-center justify-center">
                      <Church className="w-16 h-16 text-primary/50" />
                    </div>
                  )}
                  
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-2xl font-serif font-bold text-foreground">{venue.name}</h2>
                      <div className="flex items-center text-accent">
                        <Star className="w-5 h-5 fill-current" />
                        <span className="ml-1 font-medium">{venue.rating || '4.8'}</span>
                      </div>
                    </div>
                    
                    {venue.location && (
                      <div className="flex items-center text-muted-foreground mb-4">
                        <MapPin className="w-5 h-5 mr-2" />
                        <span>{venue.location.address}, {venue.location.city}</span>
                      </div>
                    )}
                    
                    <p className="text-muted-foreground mb-6">{venue.description}</p>
                    
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="flex items-center">
                        <Users className="w-5 h-5 text-primary mr-2" />
                        <div>
                          <div className="font-medium">Capacity</div>
                          <div className="text-sm text-muted-foreground">
                            {venue.capacity?.sitting || 500} guests
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Car className="w-5 h-5 text-primary mr-2" />
                        <div>
                          <div className="font-medium">Parking</div>
                          <div className="text-sm text-muted-foreground">Available</div>
                        </div>
                      </div>
                    </div>

                    {/* Islamic Facilities */}
                    {venue.islamicFacilities && (
                      <div className="border-t pt-4">
                        <h4 className="font-semibold text-foreground mb-3 flex items-center">
                          <Church className="w-5 h-5 text-primary mr-2" />
                          Islamic Facilities
                        </h4>
                        <div className="space-y-2">
                          {venue.islamicFacilities.prayerArea && (
                            <div className="flex items-center text-sm text-primary">
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Prayer Area Available
                            </div>
                          )}
                          {venue.islamicFacilities.wuduFacilities && (
                            <div className="flex items-center text-sm text-primary">
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Wudu Facilities
                            </div>
                          )}
                          {venue.islamicFacilities.qiblaDirection && (
                            <div className="flex items-center text-sm text-primary">
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Qibla Direction: {venue.islamicFacilities.qiblaDirection}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Booking Form */}
            <div>
              <Card className="booking-form">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="w-5 h-5 mr-2 text-primary" />
                    Event Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Event Type */}
                    <div>
                      <Label className="text-base font-medium mb-3 block">Event Type</Label>
                      <div className="grid grid-cols-2 gap-3">
                        {[
                          { value: 'mehndi', label: 'Mehndi' },
                          { value: 'nikah', label: 'Nikah' },
                          { value: 'walima', label: 'Walima' },
                          { value: 'reception', label: 'Reception' }
                        ].map((type) => (
                          <button
                            key={type.value}
                            type="button"
                            onClick={() => setBookingData(prev => ({ ...prev, eventType: type.value }))}
                            className={`event-type-btn p-3 rounded-lg text-sm font-medium transition-colors ${
                              bookingData.eventType === type.value 
                                ? 'active border-2 border-primary bg-primary/5 text-primary' 
                                : 'border border-border hover:border-primary hover:bg-primary/5'
                            }`}
                            data-testid={`event-type-${type.value}`}
                          >
                            <span className="block mb-1">{getEventTypeEmoji(type.value)}</span>
                            {type.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Date and Time */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="eventDate">Event Date</Label>
                        <Input
                          id="eventDate"
                          type="date"
                          min={new Date().toISOString().split('T')[0]}
                          value={bookingData.eventDate}
                          onChange={(e) => setBookingData(prev => ({ ...prev, eventDate: e.target.value }))}
                          required
                          data-testid="input-event-date"
                        />
                      </div>
                      <div>
                        <Label htmlFor="guestCount">Guest Count</Label>
                        <Input
                          id="guestCount"
                          type="number"
                          min="10"
                          max="1000"
                          value={bookingData.guestCount}
                          onChange={(e) => setBookingData(prev => ({ ...prev, guestCount: parseInt(e.target.value) || 0 }))}
                          required
                          data-testid="input-guest-count"
                        />
                      </div>
                    </div>

                    {/* Event Time */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="startTime">Start Time</Label>
                        <Input
                          id="startTime"
                          type="time"
                          value={bookingData.eventTime.start}
                          onChange={(e) => setBookingData(prev => ({ 
                            ...prev, 
                            eventTime: { ...prev.eventTime, start: e.target.value }
                          }))}
                          data-testid="input-start-time"
                        />
                      </div>
                      <div>
                        <Label htmlFor="endTime">End Time</Label>
                        <Input
                          id="endTime"
                          type="time"
                          value={bookingData.eventTime.end}
                          onChange={(e) => setBookingData(prev => ({ 
                            ...prev, 
                            eventTime: { ...prev.eventTime, end: e.target.value }
                          }))}
                          data-testid="input-end-time"
                        />
                      </div>
                    </div>

                    {/* Cultural Requirements */}
                    <div>
                      <Label className="text-base font-medium mb-3 block">Cultural Requirements</Label>
                      <div className="space-y-3">
                        {[
                          { key: 'halalFood', label: 'Halal Food Required', icon: '🥘' },
                          { key: 'prayerArrangements', label: 'Prayer Arrangements', icon: '🕌' },
                          { key: 'segregatedSeating', label: 'Segregated Seating', icon: '🪑' },
                          { key: 'islamicDecor', label: 'Islamic Decorations', icon: '🌙' }
                        ].map((req) => (
                          <div key={req.key} className="flex items-center space-x-3">
                            <Checkbox 
                              id={req.key}
                              checked={bookingData.culturalRequirements[req.key as keyof typeof bookingData.culturalRequirements]}
                              onCheckedChange={(checked) => setBookingData(prev => ({ 
                                ...prev, 
                                culturalRequirements: { 
                                  ...prev.culturalRequirements, 
                                  [req.key]: checked as boolean 
                                }
                              }))}
                              data-testid={`checkbox-${req.key}`}
                            />
                            <Label htmlFor={req.key} className="flex items-center cursor-pointer">
                              <span className="mr-2">{req.icon}</span>
                              {req.label}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Special Requests */}
                    <div>
                      <Label htmlFor="specialRequests">Special Requests</Label>
                      <Textarea
                        id="specialRequests"
                        placeholder="Any special requirements or requests for your event..."
                        value={bookingData.specialRequests}
                        onChange={(e) => setBookingData(prev => ({ ...prev, specialRequests: e.target.value }))}
                        rows={3}
                        data-testid="textarea-special-requests"
                      />
                    </div>

                    <Separator />

                    {/* Pricing Summary */}
                    <div className="bg-muted/30 p-4 rounded-lg">
                      <h4 className="font-semibold text-foreground mb-3">Pricing Summary</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Base Rate ({bookingData.guestCount} guests)</span>
                          <span>₨{calculateTotal().toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Advance Payment (30%)</span>
                          <span>₨{(calculateTotal() * 0.3).toLocaleString()}</span>
                        </div>
                        <Separator />
                        <div className="flex justify-between font-bold text-primary">
                          <span>Total Amount</span>
                          <span>₨{calculateTotal().toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    {/* Submit Button */}
                    <Button 
                      type="submit" 
                      className="w-full gradient-primary text-primary-foreground py-3 text-lg"
                      disabled={bookingMutation.isPending || !bookingData.eventDate}
                      data-testid="button-confirm-booking"
                    >
                      {bookingMutation.isPending ? (
                        <div className="flex items-center">
                          <div className="loading-spinner w-4 h-4 mr-2"></div>
                          Processing Booking...
                        </div>
                      ) : (
                        <div className="flex items-center">
                          <CheckCircle className="w-5 h-5 mr-2" />
                          Confirm Booking
                        </div>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
