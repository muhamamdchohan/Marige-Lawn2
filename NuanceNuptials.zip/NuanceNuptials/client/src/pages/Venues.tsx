import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Star, Users, Church, Car, MapPin, Filter } from "lucide-react";
import { Link } from "wouter";
import type { Venue } from "@shared/schema";

export default function Venues() {
  const [, setLocation] = useLocation();
  const [searchFilters, setSearchFilters] = useState({
    eventType: '',
    eventDate: '',
    guestCount: '',
    halalFood: false,
    prayerArea: false,
    segregatedSeating: false,
    search: ''
  });

  const { data: venues, isLoading } = useQuery<Venue[]>({
    queryKey: ['/api/venues'],
  });

  const filteredVenues = venues?.filter(venue => {
    if (searchFilters.search) {
      const searchLower = searchFilters.search.toLowerCase();
      if (!venue.name.toLowerCase().includes(searchLower) && 
          !venue.description?.toLowerCase().includes(searchLower)) {
        return false;
      }
    }
    
    if (searchFilters.guestCount) {
      const [min, max] = searchFilters.guestCount.split('-').map(n => parseInt(n.replace('+', '1000')));
      const venueCapacity = venue.capacity?.sitting || 0;
      if (max && (venueCapacity < min || venueCapacity > max)) return false;
      if (!max && venueCapacity < min) return false;
    }

    if (searchFilters.prayerArea && !venue.islamicFacilities?.prayerArea) {
      return false;
    }

    return true;
  }) || [];

  const handleBookVenue = (venueId: string) => {
    const params = new URLSearchParams();
    if (searchFilters.eventType) params.append('eventType', searchFilters.eventType);
    if (searchFilters.eventDate) params.append('eventDate', searchFilters.eventDate);
    if (searchFilters.guestCount) params.append('guestCount', searchFilters.guestCount);
    
    setLocation(`/booking/${venueId}?${params.toString()}`);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background" data-testid="venues-page">
        <div className="bg-gradient-to-br from-primary/5 to-accent/5 islamic-pattern py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <h1 className="text-4xl lg:text-5xl font-serif font-bold text-foreground mb-4">
                Premium Wedding Venues
              </h1>
              <p className="text-xl text-muted-foreground font-urdu">
                بہترین شادی کے ہال
              </p>
              <p className="text-lg text-muted-foreground mt-2">
                Discover halls that blend Pakistani traditions with modern luxury
              </p>
            </div>

            {/* Search Filters */}
            <Card className="max-w-4xl mx-auto booking-form">
              <CardContent className="pt-6">
                <div className="grid md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <Label htmlFor="search">Search Venues</Label>
                    <Input
                      id="search"
                      placeholder="Search by name or location..."
                      value={searchFilters.search}
                      onChange={(e) => setSearchFilters(prev => ({ ...prev, search: e.target.value }))}
                      data-testid="input-search-venues"
                    />
                  </div>
                  <div>
                    <Label htmlFor="eventType">Event Type</Label>
                    <Select value={searchFilters.eventType} onValueChange={(value) => setSearchFilters(prev => ({ ...prev, eventType: value }))}>
                      <SelectTrigger data-testid="select-event-type">
                        <SelectValue placeholder="Any event" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Any Event</SelectItem>
                        <SelectItem value="mehndi">Mehndi</SelectItem>
                        <SelectItem value="nikah">Nikah</SelectItem>
                        <SelectItem value="walima">Walima</SelectItem>
                        <SelectItem value="reception">Reception</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="eventDate">Event Date</Label>
                    <Input
                      id="eventDate"
                      type="date"
                      value={searchFilters.eventDate}
                      onChange={(e) => setSearchFilters(prev => ({ ...prev, eventDate: e.target.value }))}
                      data-testid="input-event-date"
                    />
                  </div>
                  <div>
                    <Label htmlFor="guestCount">Guest Count</Label>
                    <Select value={searchFilters.guestCount} onValueChange={(value) => setSearchFilters(prev => ({ ...prev, guestCount: value }))}>
                      <SelectTrigger data-testid="select-guest-count">
                        <SelectValue placeholder="Any size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Any Size</SelectItem>
                        <SelectItem value="50-100">50-100</SelectItem>
                        <SelectItem value="100-200">100-200</SelectItem>
                        <SelectItem value="200-300">200-300</SelectItem>
                        <SelectItem value="300-500">300-500</SelectItem>
                        <SelectItem value="500+">500+</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="prayerArea"
                      checked={searchFilters.prayerArea}
                      onCheckedChange={(checked) => setSearchFilters(prev => ({ ...prev, prayerArea: checked as boolean }))}
                      data-testid="checkbox-prayer-area"
                    />
                    <Label htmlFor="prayerArea" className="text-sm">Prayer Area Required</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="halalFood"
                      checked={searchFilters.halalFood}
                      onCheckedChange={(checked) => setSearchFilters(prev => ({ ...prev, halalFood: checked as boolean }))}
                      data-testid="checkbox-halal-food"
                    />
                    <Label htmlFor="halalFood" className="text-sm">Halal Catering</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="segregatedSeating"
                      checked={searchFilters.segregatedSeating}
                      onCheckedChange={(checked) => setSearchFilters(prev => ({ ...prev, segregatedSeating: checked as boolean }))}
                      data-testid="checkbox-segregated-seating"
                    />
                    <Label htmlFor="segregatedSeating" className="text-sm">Segregated Seating</Label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Venues Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-serif font-bold text-foreground">
                Available Venues ({filteredVenues.length})
              </h2>
              <p className="text-muted-foreground">Perfect halls for your special day</p>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Filter className="w-4 h-4" />
              <span>Showing {filteredVenues.length} of {venues?.length || 0} venues</span>
            </div>
          </div>

          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="venue-card bg-card shadow-lg border border-border animate-pulse">
                  <div className="w-full h-48 bg-muted"></div>
                  <div className="p-6 space-y-3">
                    <div className="h-6 bg-muted rounded w-3/4"></div>
                    <div className="h-4 bg-muted rounded w-full"></div>
                    <div className="h-4 bg-muted rounded w-2/3"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredVenues.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredVenues.map((venue) => (
                <div key={venue.id} className="venue-card bg-card shadow-lg border border-border" data-testid={`venue-card-${venue.id}`}>
                  {venue.images && venue.images.length > 0 ? (
                    <img 
                      src={venue.images[0]} 
                      alt={`${venue.name} venue`}
                      className="w-full h-48 object-cover"
                    />
                  ) : (
                    <div className="w-full h-48 bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center">
                      <Church className="w-12 h-12 text-primary/50" />
                    </div>
                  )}
                  
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-serif font-bold text-foreground" data-testid={`venue-name-${venue.id}`}>
                        {venue.name}
                      </h3>
                      <div className="flex items-center text-accent">
                        <Star className="w-4 h-4 fill-current" />
                        <span className="ml-1 text-sm font-medium">{venue.rating || '4.8'}</span>
                      </div>
                    </div>
                    
                    {venue.location && (
                      <div className="flex items-center text-sm text-muted-foreground mb-2">
                        <MapPin className="w-4 h-4 mr-1" />
                        <span>{venue.location.city}, {venue.location.province}</span>
                      </div>
                    )}
                    
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                      {venue.description || 'Beautiful venue perfect for Pakistani wedding celebrations with traditional decor and modern amenities.'}
                    </p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Users className="w-4 h-4 mr-2" />
                        <span>Up to {venue.capacity?.sitting || 500} guests</span>
                      </div>
                      {venue.islamicFacilities?.prayerArea && (
                        <div className="flex items-center text-sm text-primary">
                          <Church className="w-4 h-4 mr-2" />
                          <span>Prayer facilities available</span>
                        </div>
                      )}
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Car className="w-4 h-4 mr-2" />
                        <span>Parking available</span>
                      </div>
                    </div>

                    {/* Cultural Features */}
                    {venue.features && venue.features.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-4">
                        {venue.features.slice(0, 3).map((feature, index) => (
                          <span key={index} className="preference-badge active text-xs">
                            {feature}
                          </span>
                        ))}
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-2xl font-bold text-primary">
                          ₨{venue.pricing?.baseRate ? Number(venue.pricing.baseRate).toLocaleString() : '150,000'}
                        </span>
                        <span className="text-sm text-muted-foreground">/event</span>
                      </div>
                      <div className="space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          asChild
                          data-testid={`button-view-details-${venue.id}`}
                        >
                          <Link href={`/venues/${venue.id}`}>Details</Link>
                        </Button>
                        <Button 
                          onClick={() => handleBookVenue(venue.id)}
                          className="bg-primary text-primary-foreground hover:bg-primary/90"
                          data-testid={`button-book-venue-${venue.id}`}
                        >
                          Book Now
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">No venues found</h3>
              <p className="text-muted-foreground mb-6">
                Try adjusting your search criteria to find more options
              </p>
              <Button 
                onClick={() => setSearchFilters({
                  eventType: '',
                  eventDate: '',
                  guestCount: '',
                  halalFood: false,
                  prayerArea: false,
                  segregatedSeating: false,
                  search: ''
                })}
                variant="outline"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
