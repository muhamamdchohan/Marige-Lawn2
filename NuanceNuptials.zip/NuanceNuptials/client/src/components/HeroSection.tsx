import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Search, Building, Heart, Star } from "lucide-react";
import { useLocation } from "wouter";

export default function HeroSection() {
  const [, setLocation] = useLocation();
  const [searchForm, setSearchForm] = useState({
    eventType: 'mehndi',
    eventDate: '',
    guestCount: '',
    halalFood: false,
    prayerArea: false,
    segregatedSeating: false,
  });

  const eventTypes = [
    { value: 'mehndi', label: 'Mehndi', icon: '🤲' },
    { value: 'nikah', label: 'Nikah', icon: '🕌' },
    { value: 'walima', label: 'Walima', icon: '🍽️' },
    { value: 'reception', label: 'Reception', icon: '🥂' },
  ];

  const handleEventTypeSelect = (eventType: string) => {
    setSearchForm(prev => ({ ...prev, eventType }));
  };

  const handleSearchVenues = () => {
    const searchParams = new URLSearchParams();
    Object.entries(searchForm).forEach(([key, value]) => {
      if (value) {
        searchParams.append(key, value.toString());
      }
    });
    setLocation(`/venues?${searchParams.toString()}`);
  };

  return (
    <section className="relative bg-gradient-to-br from-primary/5 to-accent/5 islamic-pattern" data-testid="hero-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Hero Content */}
          <div className="space-y-6">
            <h1 className="text-4xl lg:text-6xl font-serif font-bold text-foreground leading-tight">
              Perfect Venues for Your
              <span className="text-primary"> Sacred Celebration</span>
            </h1>
            <p className="text-xl text-muted-foreground font-urdu leading-relaxed">
              آپ کی خوشی کے لمحات کے لیے بہترین ہال
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Discover premium wedding halls designed for Pakistani traditions, featuring Islamic facilities, halal catering, and complete event management services.
            </p>
            
            {/* Quick Stats */}
            <div className="flex flex-wrap gap-6 pt-4">
              <div className="flex items-center space-x-2" data-testid="stat-venues">
                <div className="w-10 h-10 bg-accent/10 rounded-full flex items-center justify-center">
                  <Building className="text-accent w-5 h-5" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-primary">25+</div>
                  <div className="text-sm text-muted-foreground">Premium Venues</div>
                </div>
              </div>
              <div className="flex items-center space-x-2" data-testid="stat-events">
                <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center">
                  <Heart className="text-secondary w-5 h-5" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-primary">500+</div>
                  <div className="text-sm text-muted-foreground">Successful Events</div>
                </div>
              </div>
              <div className="flex items-center space-x-2" data-testid="stat-rating">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <Star className="text-primary w-5 h-5" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-primary">4.9</div>
                  <div className="text-sm text-muted-foreground">Customer Rating</div>
                </div>
              </div>
            </div>
          </div>

          {/* Booking Widget */}
          <div className="bg-card shadow-2xl rounded-xl p-6 border border-border booking-form" data-testid="booking-widget">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-serif font-bold text-foreground">Book Your Celebration</h3>
              <p className="text-muted-foreground mt-1">Find the perfect venue for your special day</p>
            </div>

            <div className="space-y-4">
              {/* Event Type Selection */}
              <div>
                <Label className="block text-sm font-medium text-foreground mb-2">Event Type</Label>
                <div className="grid grid-cols-2 gap-2">
                  {eventTypes.map((type) => (
                    <button
                      key={type.value}
                      onClick={() => handleEventTypeSelect(type.value)}
                      className={`event-type-btn px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                        searchForm.eventType === type.value 
                          ? 'active border-2 border-primary bg-primary/5 text-primary' 
                          : 'border border-border hover:border-primary hover:bg-primary/5'
                      }`}
                      data-testid={`event-type-${type.value}`}
                    >
                      <span className="block mb-1">{type.icon}</span>
                      {type.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Date and Guests */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="eventDate" className="block text-sm font-medium text-foreground mb-2">
                    Event Date
                  </Label>
                  <Input
                    id="eventDate"
                    type="date"
                    value={searchForm.eventDate}
                    onChange={(e) => setSearchForm(prev => ({ ...prev, eventDate: e.target.value }))}
                    className="w-full"
                    data-testid="input-event-date"
                  />
                </div>
                <div>
                  <Label htmlFor="guestCount" className="block text-sm font-medium text-foreground mb-2">
                    Guests
                  </Label>
                  <Select value={searchForm.guestCount} onValueChange={(value) => setSearchForm(prev => ({ ...prev, guestCount: value }))}>
                    <SelectTrigger data-testid="select-guest-count">
                      <SelectValue placeholder="Select guests" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="50-100">50-100</SelectItem>
                      <SelectItem value="100-200">100-200</SelectItem>
                      <SelectItem value="200-300">200-300</SelectItem>
                      <SelectItem value="300-500">300-500</SelectItem>
                      <SelectItem value="500+">500+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Cultural Preferences */}
              <div>
                <Label className="block text-sm font-medium text-foreground mb-2">Cultural Requirements</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="halalFood"
                      checked={searchForm.halalFood}
                      onCheckedChange={(checked) => setSearchForm(prev => ({ ...prev, halalFood: checked as boolean }))}
                      data-testid="checkbox-halal-food"
                    />
                    <Label htmlFor="halalFood" className="text-sm text-foreground">
                      Halal Food Required
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="prayerArea"
                      checked={searchForm.prayerArea}
                      onCheckedChange={(checked) => setSearchForm(prev => ({ ...prev, prayerArea: checked as boolean }))}
                      data-testid="checkbox-prayer-area"
                    />
                    <Label htmlFor="prayerArea" className="text-sm text-foreground">
                      Prayer Area Required
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="segregatedSeating"
                      checked={searchForm.segregatedSeating}
                      onCheckedChange={(checked) => setSearchForm(prev => ({ ...prev, segregatedSeating: checked as boolean }))}
                      data-testid="checkbox-segregated-seating"
                    />
                    <Label htmlFor="segregatedSeating" className="text-sm text-foreground">
                      Segregated Seating
                    </Label>
                  </div>
                </div>
              </div>

              {/* Search Button */}
              <Button 
                onClick={handleSearchVenues}
                className="w-full gradient-primary text-primary-foreground py-3 text-lg shadow-lg hover:shadow-xl transition-all"
                data-testid="button-search-venues"
              >
                <Search className="w-5 h-5 mr-2" />
                Find Perfect Venues
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
