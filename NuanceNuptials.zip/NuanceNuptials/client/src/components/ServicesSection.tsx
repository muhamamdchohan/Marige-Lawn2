import { Calendar, Utensils, Camera, Church, Palette, Car, Music, CheckCircle } from "lucide-react";

export default function ServicesSection() {
  const mainServices = [
    {
      icon: Calendar,
      title: "Event Planning",
      description: "Complete timeline management for Mehndi, Nikah, and Walima ceremonies",
      color: "primary"
    },
    {
      icon: Utensils,
      title: "Halal Catering",
      description: "Authentic Pakistani cuisine with halal certification and dietary preferences",
      color: "accent"
    },
    {
      icon: Camera,
      title: "Photography",
      description: "Professional photographers experienced in Pakistani wedding traditions",
      color: "secondary"
    },
    {
      icon: Church,
      title: "Islamic Services",
      description: "Prayer arrangements, Nikah ceremonies, and Islamic décor elements",
      color: "primary"
    }
  ];

  const additionalServices = [
    {
      icon: Palette,
      title: "Decoration & Styling",
      description: "Traditional Pakistani wedding decorations with modern touches, including stage setup, floral arrangements, and cultural themes.",
      features: [
        "Traditional stage decoration",
        "Mehndi ceremony setup", 
        "Fresh flower arrangements"
      ],
      color: "accent"
    },
    {
      icon: Car,
      title: "Transportation",
      description: "Luxury transportation services for bride, groom, and family members with decorated vehicles for special occasions.",
      features: [
        "Bridal car decoration",
        "Family transportation",
        "Guest shuttle service"
      ],
      color: "secondary"
    },
    {
      icon: Music,
      title: "Entertainment",
      description: "Professional entertainment services including traditional Pakistani music, DJs, and cultural performances.",
      features: [
        "Traditional music bands",
        "Professional DJ services",
        "Cultural dance performances"
      ],
      color: "primary"
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'primary':
        return 'bg-primary/10 text-primary hover:bg-primary/20';
      case 'accent':
        return 'bg-accent/10 text-accent hover:bg-accent/20';
      case 'secondary':
        return 'bg-secondary/10 text-secondary hover:bg-secondary/20';
      default:
        return 'bg-primary/10 text-primary hover:bg-primary/20';
    }
  };

  return (
    <section className="py-16 bg-muted/30" data-testid="services-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-serif font-bold text-foreground mb-4">
            Complete Wedding Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need for a perfect Pakistani wedding celebration
          </p>
        </div>

        {/* Main Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {mainServices.map((service, index) => (
            <div key={index} className="text-center group" data-testid={`service-${service.title.toLowerCase().replace(' ', '-')}`}>
              <div className={`w-16 h-16 ${getColorClasses(service.color)} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-all duration-300`}>
                <service.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-serif font-bold text-foreground mb-2">{service.title}</h3>
              <p className="text-muted-foreground">{service.description}</p>
            </div>
          ))}
        </div>

        {/* Additional Services Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {additionalServices.map((service, index) => (
            <div key={index} className="bg-card rounded-xl p-6 border border-border shadow-sm hover:shadow-md transition-shadow" data-testid={`detailed-service-${service.title.toLowerCase().replace(' ', '-')}`}>
              <div className="flex items-center mb-4">
                <div className={`w-12 h-12 ${getColorClasses(service.color)} rounded-full flex items-center justify-center mr-4`}>
                  <service.icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-serif font-bold text-foreground">{service.title}</h3>
              </div>
              <p className="text-muted-foreground mb-4">{service.description}</p>
              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-primary mr-2 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
