import { Star } from "lucide-react";

export default function TestimonialsSection() {
  const testimonials = [
    {
      name: "Ahmed & Fatima Rahman",
      event: "Nikah Ceremony",
      rating: 5,
      review: "Alhamdulillah! The team made our Nikah ceremony perfect. The prayer arrangements were excellent and the halal food was delicious. Highly recommended for Pakistani families.",
      initials: "AR"
    },
    {
      name: "Sarah & Kareem Ali", 
      event: "Mehndi & Walima",
      rating: 5,
      review: "The Mehndi decorations were absolutely stunning! Traditional Pakistani colors and the garden setting was perfect. Our families loved every moment. جزاک اللہ!",
      initials: "SK"
    },
    {
      name: "Maria & Hassan Sheikh",
      event: "Grand Reception", 
      rating: 5,
      review: "Professional service from start to finish. The Crystal Ballroom was elegantly decorated and the staff was very accommodating to our cultural requirements. Truly memorable!",
      initials: "MH"
    }
  ];

  const getInitialsColor = (index: number) => {
    const colors = ['bg-primary', 'bg-secondary', 'bg-accent'];
    return colors[index % colors.length];
  };

  return (
    <section className="py-16 bg-muted/30" data-testid="testimonials-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-serif font-bold text-foreground mb-4">
            What Our Families Say
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Hear from Pakistani families who trusted us with their special celebrations
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index} 
              className="bg-card rounded-xl p-6 border border-border shadow-sm hover:shadow-md transition-shadow"
              data-testid={`testimonial-${index + 1}`}
            >
              <div className="flex items-center mb-4">
                <div className={`w-12 h-12 ${getInitialsColor(index)} rounded-full flex items-center justify-center mr-4`}>
                  <span className="text-white font-bold">{testimonial.initials}</span>
                </div>
                <div>
                  <h4 className="font-bold text-foreground" data-testid={`testimonial-name-${index + 1}`}>
                    {testimonial.name}
                  </h4>
                  <p className="text-sm text-muted-foreground">{testimonial.event}</p>
                </div>
              </div>
              
              <div className="flex items-center mb-3" data-testid={`testimonial-rating-${index + 1}`}>
                <div className="flex text-accent">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
              </div>
              
              <p className="text-muted-foreground italic" data-testid={`testimonial-review-${index + 1}`}>
                "{testimonial.review}"
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
