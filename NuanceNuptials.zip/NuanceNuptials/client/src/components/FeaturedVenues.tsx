import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Star, Users, Church, Car } from "lucide-react";
import { Link } from "wouter";
import type { Venue } from "@shared/schema";

export default function FeaturedVenues() {
  const { data: venues, isLoading } = useQuery<Venue[]>({
    queryKey: ['/api/venues'],
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-background" data-testid="featured-venues-loading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-foreground mb-4">
              Premium Wedding Venues
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Carefully selected halls that blend Pakistani traditions with modern amenities
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="venue-card bg-card shadow-lg border border-border animate-pulse">
                <div className="w-full h-48 bg-muted rounded-t-lg"></div>
                <div className="p-6 space-y-3">
                  <div className="h-6 bg-muted rounded w-3/4"></div>
                  <div className="h-4 bg-muted rounded w-full"></div>
                  <div className="h-4 bg-muted rounded w-2/3"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  const featuredVenues = venues?.slice(0, 3) || [];

  return (
    <section className="py-16 bg-background" data-testid="featured-venues">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-serif font-bold text-foreground mb-4">
            Premium Wedding Venues
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Carefully selected halls that blend Pakistani traditions with modern amenities
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredVenues.map((venue) => (
            <div key={venue.id} className="venue-card bg-card shadow-lg border border-border" data-testid={`venue-card-${venue.id}`}>
              {venue.images && venue.images.length > 0 ? (
                <img 
                  src={venue.images[0]} 
                  alt={`${venue.name} venue`}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
              ) : (
                <div className="w-full h-48 bg-gradient-to-br from-primary/10 to-accent/10 rounded-t-lg flex items-center justify-center">
                  <Church className="w-12 h-12 text-primary/50" />
                </div>
              )}
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-serif font-bold text-foreground" data-testid={`venue-name-${venue.id}`}>
                    {venue.name}
                  </h3>
                  <div className="flex items-center text-accent">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="ml-1 text-sm font-medium" data-testid={`venue-rating-${venue.id}`}>
                      {venue.rating || '4.8'}
                    </span>
                  </div>
                </div>
                
                <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                  {venue.description || 'Beautiful venue perfect for Pakistani wedding celebrations with traditional decor and modern amenities.'}
                </p>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Users className="w-4 h-4 mr-2" />
                    <span>Up to {venue.capacity?.sitting || 500} guests</span>
                  </div>
                  {venue.islamicFacilities?.prayerArea && (
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Church className="w-4 h-4 mr-2" />
                      <span>Prayer facilities available</span>
                    </div>
                  )}
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Car className="w-4 h-4 mr-2" />
                    <span>Free parking available</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-2xl font-bold text-primary">
                      ₨{venue.pricing?.baseRate ? Number(venue.pricing.baseRate).toLocaleString() : '150,000'}
                    </span>
                    <span className="text-sm text-muted-foreground">/event</span>
                  </div>
                  <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90" data-testid={`button-view-venue-${venue.id}`}>
                    <Link href={`/venues/${venue.id}`}>View Details</Link>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {venues && venues.length > 3 && (
          <div className="text-center mt-12">
            <Button asChild className="bg-secondary text-secondary-foreground hover:bg-secondary/90" data-testid="button-view-all-venues">
              <Link href="/venues">
                <Building className="w-5 h-5 mr-2" />
                View All Venues
              </Link>
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}
