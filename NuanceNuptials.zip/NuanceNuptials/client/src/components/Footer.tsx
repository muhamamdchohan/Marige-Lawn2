import { Link } from "wouter";
import { Church, Facebook, Instagram, MessageCircle } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground" data-testid="footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand Info */}
          <div className="md:col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-primary-foreground rounded-full flex items-center justify-center">
                <Church className="text-primary text-sm" />
              </div>
              <div>
                <span className="text-xl font-serif font-bold">Shaadi Palace</span>
                <p className="text-xs font-urdu">شادی پیلس</p>
              </div>
            </div>
            <p className="text-primary-foreground/80 text-sm mb-4">
              Making Pakistani wedding dreams come true with traditional values and modern convenience.
            </p>
            <div className="flex space-x-3">
              <a 
                href="#" 
                className="w-8 h-8 bg-primary-foreground/10 hover:bg-primary-foreground/20 rounded-full flex items-center justify-center transition-colors"
                data-testid="social-facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a 
                href="#" 
                className="w-8 h-8 bg-primary-foreground/10 hover:bg-primary-foreground/20 rounded-full flex items-center justify-center transition-colors"
                data-testid="social-instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a 
                href="#" 
                className="w-8 h-8 bg-primary-foreground/10 hover:bg-primary-foreground/20 rounded-full flex items-center justify-center transition-colors"
                data-testid="social-whatsapp"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-serif font-bold text-lg mb-4">Services</h4>
            <ul className="space-y-2 text-sm text-primary-foreground/80">
              <li>
                <Link href="/venues">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Wedding Venues</span>
                </Link>
              </li>
              <li>
                <Link href="/services/mehndi">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Mehndi Ceremonies</span>
                </Link>
              </li>
              <li>
                <Link href="/services/nikah">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Nikah Services</span>
                </Link>
              </li>
              <li>
                <Link href="/services/walima">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Walima Receptions</span>
                </Link>
              </li>
              <li>
                <Link href="/services/planning">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Event Planning</span>
                </Link>
              </li>
              <li>
                <Link href="/services/catering">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Halal Catering</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-serif font-bold text-lg mb-4">Company</h4>
            <ul className="space-y-2 text-sm text-primary-foreground/80">
              <li>
                <Link href="/about">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">About Us</span>
                </Link>
              </li>
              <li>
                <Link href="/story">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Our Story</span>
                </Link>
              </li>
              <li>
                <Link href="/careers">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Careers</span>
                </Link>
              </li>
              <li>
                <Link href="/press">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Press</span>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Contact</span>
                </Link>
              </li>
              <li>
                <Link href="/blog">
                  <span className="hover:text-primary-foreground transition-colors cursor-pointer">Blog</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-serif font-bold text-lg mb-4">Contact</h4>
            <div className="space-y-3 text-sm text-primary-foreground/80">
              <div className="flex items-center">
                <span className="mr-3">📞</span>
                <span>+92 321 1234567</span>
              </div>
              <div className="flex items-center">
                <span className="mr-3">📧</span>
                <span>info@shaadipalace.pk</span>
              </div>
              <div className="flex items-start">
                <span className="mr-3 mt-1">📍</span>
                <span>Gulberg III, Lahore,<br />Punjab, Pakistan</span>
              </div>
              <div className="flex items-center">
                <span className="mr-3">🕒</span>
                <span>24/7 Support</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-primary-foreground/20 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-primary-foreground/80">
              © 2024 Shaadi Palace. All rights reserved. Made with ❤️ for Pakistani families.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0 text-sm text-primary-foreground/80">
              <Link href="/privacy">
                <span className="hover:text-primary-foreground transition-colors cursor-pointer">Privacy Policy</span>
              </Link>
              <Link href="/terms">
                <span className="hover:text-primary-foreground transition-colors cursor-pointer">Terms of Service</span>
              </Link>
              <Link href="/support">
                <span className="hover:text-primary-foreground transition-colors cursor-pointer">Support</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
