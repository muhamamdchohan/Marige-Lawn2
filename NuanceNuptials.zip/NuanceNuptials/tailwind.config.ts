import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./client/index.html", "./client/src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        card: {
          DEFAULT: "var(--card)",
          foreground: "var(--card-foreground)",
        },
        popover: {
          DEFAULT: "var(--popover)",
          foreground: "var(--popover-foreground)",
        },
        primary: {
          DEFAULT: "var(--primary)",
          foreground: "var(--primary-foreground)",
        },
        secondary: {
          DEFAULT: "var(--secondary)",
          foreground: "var(--secondary-foreground)",
        },
        muted: {
          DEFAULT: "var(--muted)",
          foreground: "var(--muted-foreground)",
        },
        accent: {
          DEFAULT: "var(--accent)",
          foreground: "var(--accent-foreground)",
        },
        destructive: {
          DEFAULT: "var(--destructive)",
          foreground: "var(--destructive-foreground)",
        },
        border: "var(--border)",
        input: "var(--input)",
        ring: "var(--ring)",
        chart: {
          "1": "var(--chart-1)",
          "2": "var(--chart-2)",
          "3": "var(--chart-3)",
          "4": "var(--chart-4)",
          "5": "var(--chart-5)",
        },
        sidebar: {
          DEFAULT: "var(--sidebar)",
          foreground: "var(--sidebar-foreground)",
          primary: "var(--sidebar-primary)",
          "primary-foreground": "var(--sidebar-primary-foreground)",
          accent: "var(--sidebar-accent)",
          "accent-foreground": "var(--sidebar-accent-foreground)",
          border: "var(--sidebar-border)",
          ring: "var(--sidebar-ring)",
        },
        // Pakistani cultural colors
        'pakistan-green': {
          50: '#f0f9f3',
          100: '#dcf2e1',
          200: '#bce5c7',
          300: '#8fd1a3',
          400: '#5bb377',
          500: '#369654',
          600: '#228B22',
          700: '#006A4E',
          800: '#01411C',
          900: '#013318',
        },
        'pakistan-gold': {
          50: '#fffbeb',
          100: '#fef3c7',
          200: '#fde68a',
          300: '#fcd34d',
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
          700: '#b45309',
          800: '#92400e',
          900: '#78350f',
        },
        'mehndi': {
          DEFAULT: '#FFD700',
          light: '#FFF8DC',
          dark: '#DAA520',
        },
        'nikah': {
          DEFAULT: '#FFFFFF',
          light: '#F8F8FF',
          dark: '#F5F5DC',
        },
        'walima': {
          DEFAULT: '#DC143C',
          light: '#FFB6C1',
          dark: '#B22222',
        },
        'islamic': {
          DEFAULT: '#006A4E',
          light: '#228B22',
          dark: '#01411C',
        }
      },
      fontFamily: {
        sans: ["var(--font-sans)"],
        serif: ["var(--font-serif)"],
        mono: ["var(--font-mono)"],
        urdu: ["var(--font-urdu)"],
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
        "fade-in": {
          from: {
            opacity: "0",
            transform: "translateY(10px)",
          },
          to: {
            opacity: "1",
            transform: "translateY(0)",
          },
        },
        "slide-in": {
          from: {
            transform: "translateX(-100%)",
          },
          to: {
            transform: "translateX(0)",
          },
        },
        "sparkle": {
          "0%, 100%": {
            opacity: "0.5",
            transform: "scale(1)",
          },
          "50%": {
            opacity: "1",
            transform: "scale(1.1)",
          },
        },
        "celebrate": {
          "0%, 100%": {
            transform: "scale(1) rotate(0deg)",
          },
          "25%": {
            transform: "scale(1.1) rotate(5deg)",
          },
          "75%": {
            transform: "scale(1.1) rotate(-5deg)",
          },
        },
        "gradient-shift": {
          "0%": {
            "background-position": "0% 50%",
          },
          "50%": {
            "background-position": "100% 50%",
          },
          "100%": {
            "background-position": "0% 50%",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "fade-in": "fade-in 0.5s ease-out",
        "slide-in": "slide-in 0.3s ease-out",
        "sparkle": "sparkle 2s ease-in-out infinite",
        "celebrate": "celebrate 1s ease-in-out",
        "gradient-shift": "gradient-shift 8s ease infinite",
      },
      backgroundImage: {
        'islamic-pattern': "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23006A4E' fill-opacity='0.05'%3E%3Cpath d='M30 0L60 30L30 60L0 30z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
        'mosque-pattern': "url(\"data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23FFD700' fill-opacity='0.1'%3E%3Cpath d='M20 5 L15 15 L25 15 Z M10 15 L30 15 L30 25 L10 25 Z M15 25 L25 25 L25 35 L15 35 Z'/%3E%3C/g%3E%3C/svg%3E\")",
        'gradient-primary': 'linear-gradient(135deg, var(--primary) 0%, hsl(156, 95%, 25%) 100%)',
        'gradient-gold': 'linear-gradient(135deg, var(--accent) 0%, hsl(43, 90%, 50%) 100%)',
        'gradient-secondary': 'linear-gradient(135deg, var(--secondary) 0%, hsl(320, 45%, 45%) 100%)',
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '128': '32rem',
      },
      aspectRatio: {
        'venue': '16 / 10',
        'gallery': '4 / 3',
      },
    },
  },
  plugins: [
    require("tailwindcss-animate"), 
    require("@tailwindcss/typography"),
    // Custom plugin for Pakistani wedding themes
    function({ addUtilities }: any) {
      const newUtilities = {
        '.text-urdu': {
          fontFamily: 'var(--font-urdu)',
          direction: 'rtl',
          textAlign: 'right',
        },
        '.gradient-primary': {
          background: 'linear-gradient(135deg, var(--primary) 0%, hsl(156, 95%, 25%) 100%)',
        },
        '.gradient-gold': {
          background: 'linear-gradient(135deg, var(--accent) 0%, hsl(43, 90%, 50%) 100%)',
        },
        '.islamic-pattern': {
          backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23006A4E' fill-opacity='0.05'%3E%3Cpath d='M30 0L60 30L30 60L0 30z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
        },
        '.wedding-card': {
          border: '2px solid transparent',
          background: 'linear-gradient(white, white) padding-box, linear-gradient(45deg, var(--primary), var(--accent)) border-box',
          borderRadius: 'var(--radius)',
          transition: 'all 0.3s ease',
        },
        '.wedding-card:hover': {
          transform: 'translateY(-4px)',
          boxShadow: '0 8px 32px rgba(0, 106, 78, 0.2)',
        },
      }
      addUtilities(newUtilities)
    }
  ],
} satisfies Config;
