import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  decimal,
  pgEnum
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table with Pakistani cultural fields
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role", { enum: ["customer", "admin", "staff"] }).default("customer"),
  phone: varchar("phone"),
  cnic: varchar("cnic"), // Pakistani CNIC
  address: jsonb("address").$type<{
    street: string;
    city: string;
    province: string;
    country: string;
  }>(),
  preferences: jsonb("preferences").$type<{
    language: "urdu" | "english";
    communicationMethod: "whatsapp" | "sms" | "email";
    culturalPreferences: string[];
  }>(),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Event types enum
export const eventTypeEnum = pgEnum("event_type", ["mehndi", "nikah", "walima", "reception"]);
export const bookingStatusEnum = pgEnum("booking_status", ["pending", "confirmed", "cancelled", "completed"]);
export const paymentStatusEnum = pgEnum("payment_status", ["pending", "partial", "complete", "refunded"]);

// Venues table
export const venues = pgTable("venues", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  capacity: jsonb("capacity").$type<{
    sitting: number;
    standing: number;
  }>(),
  features: jsonb("features").$type<string[]>(),
  islamicFacilities: jsonb("islamic_facilities").$type<{
    prayerArea: boolean;
    wuduFacilities: boolean;
    qiblaDirection: string;
  }>(),
  pricing: jsonb("pricing").$type<{
    baseRate: number;
    weekendRate: number;
    peakSeasonRate: number;
  }>(),
  images: jsonb("images").$type<string[]>(),
  location: jsonb("location").$type<{
    address: string;
    city: string;
    province: string;
    coordinates: { lat: number; lng: number };
  }>(),
  rating: decimal("rating", { precision: 2, scale: 1 }).default("0.0"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Bookings table
export const bookings = pgTable("bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").references(() => users.id),
  venueId: varchar("venue_id").references(() => venues.id),
  eventType: eventTypeEnum("event_type").notNull(),
  eventDate: timestamp("event_date").notNull(),
  eventTime: jsonb("event_time").$type<{
    start: string;
    end: string;
  }>(),
  guestCount: integer("guest_count").notNull(),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }),
  advancePayment: decimal("advance_payment", { precision: 10, scale: 2 }),
  remainingAmount: decimal("remaining_amount", { precision: 10, scale: 2 }),
  paymentStatus: paymentStatusEnum("payment_status").default("pending"),
  bookingStatus: bookingStatusEnum("booking_status").default("pending"),
  specialRequests: text("special_requests"),
  culturalRequirements: jsonb("cultural_requirements").$type<{
    prayerArrangements: boolean;
    halalFood: boolean;
    segregatedSeating: boolean;
    islamicDecor: boolean;
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Packages table
export const packages = pgTable("packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  services: jsonb("services").$type<string[]>(),
  price: decimal("price", { precision: 10, scale: 2 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Payments table
export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  bookingId: varchar("booking_id").references(() => bookings.id),
  amount: decimal("amount", { precision: 10, scale: 2 }),
  paymentMethod: varchar("payment_method"), // stripe, jazzcash, bank_transfer
  stripePaymentIntentId: varchar("stripe_payment_intent_id"),
  status: varchar("status"), // pending, completed, failed, refunded
  paidAt: timestamp("paid_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Reviews table
export const reviews = pgTable("reviews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").references(() => users.id),
  venueId: varchar("venue_id").references(() => venues.id),
  bookingId: varchar("booking_id").references(() => bookings.id),
  rating: integer("rating"), // 1-5
  comment: text("comment"),
  isApproved: boolean("is_approved").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  bookings: many(bookings),
  reviews: many(reviews),
}));

export const venuesRelations = relations(venues, ({ many }) => ({
  bookings: many(bookings),
  reviews: many(reviews),
}));

export const bookingsRelations = relations(bookings, ({ one, many }) => ({
  customer: one(users, {
    fields: [bookings.customerId],
    references: [users.id],
  }),
  venue: one(venues, {
    fields: [bookings.venueId],
    references: [venues.id],
  }),
  payments: many(payments),
  review: one(reviews),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  booking: one(bookings, {
    fields: [payments.bookingId],
    references: [bookings.id],
  }),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  customer: one(users, {
    fields: [reviews.customerId],
    references: [users.id],
  }),
  venue: one(venues, {
    fields: [reviews.venueId],
    references: [venues.id],
  }),
  booking: one(bookings, {
    fields: [reviews.bookingId],
    references: [bookings.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertVenueSchema = createInsertSchema(venues).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Venue = typeof venues.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type Package = typeof packages.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type Review = typeof reviews.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertVenue = z.infer<typeof insertVenueSchema>;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type InsertReview = z.infer<typeof insertReviewSchema>;
